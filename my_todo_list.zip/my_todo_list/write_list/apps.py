from django.apps import AppConfig


class WriteListConfig(AppConfig):
    name = 'write_list'
