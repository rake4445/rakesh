from django.contrib import admin
from .models import List

admin.site.register(List)

# Register your models here.
